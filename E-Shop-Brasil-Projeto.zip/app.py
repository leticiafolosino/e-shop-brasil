import streamlit as st
from pymongo import MongoClient
import pandas as pd

# Conexão com o MongoDB
client = MongoClient("mongodb://mongo:27017/")
db = client["eshop"]
colecao = db["clientes"]

st.title("E-Shop Brasil - Gestão de Dados")

# Inserção de Dados
st.header("Inserir Novo Cliente")
with st.form("inserir_form"):
    cliente_id = st.text_input("ID do Cliente")
    nome = st.text_input("Nome")
    email = st.text_input("Email")
    produto = st.text_input("Produto Comprado")
    valor = st.number_input("Valor da Compra", min_value=0.0, step=0.01)
    regiao = st.selectbox("Região", ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"])
    submitted = st.form_submit_button("Inserir")
    if submitted:
        novo_cliente = {
            "cliente_id": cliente_id,
            "nome": nome,
            "email": email,
            "compras": [{"produto": produto, "valor": valor}],
            "regiao": regiao
        }
        colecao.insert_one(novo_cliente)
        st.success("Cliente inserido com sucesso!")

# Consulta de Dados
st.header("Clientes Cadastrados")
dados = list(colecao.find({}, {"_id": 0}))
df = pd.DataFrame(dados)
st.dataframe(df)

# Edição e Exclusão
st.header("Editar ou Excluir Cliente")
id_para_editar = st.text_input("ID do Cliente para Editar ou Excluir")
opcao = st.radio("Escolha a ação", ["Editar", "Excluir"])

if st.button("Executar Ação"):
    if opcao == "Excluir":
        colecao.delete_one({"cliente_id": id_para_editar})
        st.success("Cliente excluído com sucesso!")
    elif opcao == "Editar":
        novo_nome = st.text_input("Novo Nome", key="edit_nome")
        novo_email = st.text_input("Novo Email", key="edit_email")
        if st.button("Salvar Edição"):
            colecao.update_one(
                {"cliente_id": id_para_editar},
                {"$set": {"nome": novo_nome, "email": novo_email}}
            )
            st.success("Cliente editado com sucesso!")

# Concatenação de Dados
st.header("Concatenar Dados com Outra Coleção")
if st.button("Concatenar"):
    outra_colecao = db["clientes_backup"]
    for doc in colecao.find({}):
        outra_colecao.insert_one(doc)
    st.success("Dados copiados para a coleção 'clientes_backup'.")
