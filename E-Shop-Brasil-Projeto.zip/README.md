# E-Shop Brasil - Solução com Big Data e Banco de Dados

## Introdução

A E-Shop Brasil é uma das maiores plataformas de e-commerce do país, enfrentando desafios crescentes em gestão de dados, personalização e logística. Este projeto propõe uma solução prática utilizando tecnologias avançadas de banco de dados (NoSQL) e Big Data para atender a essas necessidades.

## Objetivos do Projeto

- Garantir a segurança e privacidade dos dados dos clientes.
- Proporcionar personalização com base no comportamento de compra.
- Otimizar a logística de entrega, especialmente em regiões distantes.
- Escalar a solução de forma sustentável usando tecnologias modernas.

## Descrição do Projeto

A aplicação foi construída com:

- **Docker**: Para isolamento e padronização do ambiente.
- **MongoDB**: Para armazenar e manipular grandes volumes de dados.
- **Streamlit**: Para construir uma interface visual e prática.

## Estrutura

- `app.py`: Aplicação principal com Streamlit.
- `docker-compose.yml`: Orquestração dos serviços (MongoDB e aplicação).
- `dados_iniciais.json`: Dados iniciais fictícios.
- `exemplos/`: Prints ou GIFs demonstrando o uso da aplicação.

## Passos para Execução

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/e-shop-brasil.git
cd e-shop-brasil
```

2. Suba a infraestrutura com Docker Compose:
```bash
docker-compose up --build
```

3. Acesse a aplicação em:
```
http://localhost:8501
```

## Funcionalidades

- Inserção de dados no MongoDB.
- Edição e exclusão de registros.
- Concatenar dados entre coleções.
- Consultas e exibição na interface Streamlit.

## Testes e Exemplos

Veja a pasta `exemplos/` para capturas de tela demonstrando as funcionalidades da aplicação.

Desenvolvido como parte do projeto prático de Tecnologias Avançadas de Banco de Dados e Big Data.
